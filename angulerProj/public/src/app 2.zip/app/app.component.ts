import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

    newCake: any;
    newRating: any;
    SavedId: String;

    constructor(private _httpService: HttpService){}

    ngOnInit(){
      this.newCake = { title: "", description: "" }
      this.newRating = { stars: 0, comment: ""};
      this.getCakesFromService();
    } 
    cakes = [];
    task = [];
    getCakesFromService(){
       let observable = this._httpService.getTasks();
       observable.subscribe(data => {
          console.log("Got our cakes!", data)
          this.cakes = data['data'];
          console.log(this.cakes)
       });
    }

    // onDelete(){
    //   let obs = this._httpService.deleteTask(this.SavedId);
    //   obs.subscribe(data => {
    //     console.log("updated task");
    //   })
    //   this.getCakesFromService();
    // }

    // onEdit(){
    //   let observable = this._httpService.updateTask(this.SavedId, this.task[0].title, this.task[0].description);
    //   observable.subscribe(data => {
    //     console.log("updated task");
    //   })
    //   this.getCakesFromService();
    // }
  postRate(id){
    let observable = this._httpService.addRating(this.newRating, id);
    observable.subscribe(data=> {
      console.log("added rating");
    })
    this.newRating = { stars: 0, comment: ""};
  }

  onSubmit() {
    let observable = this._httpService.addCake(this.newCake);
    observable.subscribe(data => {
      console.log("submitted add task");
    })
    this.newCake = { title: "", description: "" }
    this.getCakesFromService();
  }

  getSpecificTaskFromService(id){
    this.SavedId = id;
    let observable = this._httpService.getTaskbyID(id);
    observable.subscribe(data => {
      console.log("Got our tasks!", data)
      this.task = data['data'];
      console.log(this.cakes)
    })
  }

  onButtonClickCakeShow(id): void { 
    console.log(`Cake Click event is working`);
    this.getSpecificTaskFromService(id);
  }

  onButtonClickCakes(): void { 
    console.log(`Click event is working`);
    this.getCakesFromService();
  }

}

