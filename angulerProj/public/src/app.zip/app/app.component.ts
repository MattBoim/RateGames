import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

    newTask: any;
    SavedId: String;

    constructor(private _httpService: HttpService){}

    ngOnInit(){
      this.newTask = { title: "", description: "" }
    } 
    tasks = [];
    task = [];
    getTasksFromService(){
       let observable = this._httpService.getTasks();
       observable.subscribe(data => {
          console.log("Got our tasks!", data)
          this.tasks = data['data'];
          console.log(this.tasks)
       });
    }

    onDelete(){
      let obs = this._httpService.deleteTask(this.SavedId);
      obs.subscribe(data => {
        console.log("updated task");
      })
      this.onButtonClickTasks();
    }

    onEdit(){
      let observable = this._httpService.updateTask(this.SavedId, this.task[0].title, this.task[0].description);
      observable.subscribe(data => {
        console.log("updated task");
      })
      this.onButtonClickTasks();
    }

    onSubmit() {
      // Code to send off the form data (this.newTask) to the Service
      let observable = this._httpService.addTask(this.newTask);
      observable.subscribe(data => {
        console.log("submitted add task");
      })
      // Reset this.newTask to a new, clean object.
      this.newTask = { title: "", description: "" }
      this.onButtonClickTasks();
    }

  getSpecificTaskFromService(id){
    this.SavedId = id;
    let observable = this._httpService.getTaskbyID(id);
    observable.subscribe(data => {
      console.log("Got our tasks!", data)
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object. 
      // This may be different for you, depending on how you set up your Task API.
      this.task = data['data'];
      console.log(this.tasks)
    })
  }

  onButtonClickTasksShow(id): void { 
    console.log(`Click event is working`);
    this.getSpecificTaskFromService(id);
  }

  onButtonClickTasks(): void { 
    console.log(`Click event is working`);
    this.getTasksFromService();
  }
  
//   onButtonClick(): void { 
//     console.log(`Click event is working`);
//   }
//   onButtonClickParam(num: Number): void { 
//     console.log(`Click event is working with num param: ${num}`);
//     // call the service's method to post the data, but make sure the data is bundled up in an object!
//     let observable = this._httpService.postToServer({data: num}); //posttoserver from service.ts
//     observable.subscribe(data => console.log("Got our data!", data));
//   }
//   onButtonClickParams(num: Number, str: String): void { 
//       console.log(`Click event is working with num param: ${num} and str param: ${str}`);
//   }
//   onButtonClickEvent(event: any): void { 
//       console.log(`Click event is working with event: ${event}`);
//   }

}

